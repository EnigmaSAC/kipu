<?php

return [

    'message' => [
        'sent'      => 'Apakah Anda yakin ingin menandai credit/debit note yang dipilih sebagai <b> berbayar </b>? Apakah Anda yakin ingin menandai credit/debit note yang dipilih sebagai <b> berbayar </b>?',
        'cancelled' => 'Apakah Anda yakin ingin <b> membatalkan </b>credit/debit note yang dipilih? Apakah Anda yakin ingin <b> membatalkan </b> credit/debit note yang dipilih?',
    ],

];
