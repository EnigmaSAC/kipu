<?php

return [

    'message' => [
        'sent'      => 'Vai tiešām vēlaties atzīmēt atlasīto :veids as <b>nosūtīts</b>?|Vai tiešām vēlaties atzīmēt atlasīto :veids kā <b>nosūtīts</b>?',
        'cancelled' => 'Vai tiešām vēlaties <b>atcelt</b> atlasīto :veids?|Vai tiešām vēlaties <b>atcelt</b> atlasīto :veids?',
        'delete'    => 'Vai tiešām vēlaties <b>dzēst</b> atlasīto :veids?|Vai tiešām vēlaties <b>dzēst</b> atlasīto :veids?',
    ],

];
