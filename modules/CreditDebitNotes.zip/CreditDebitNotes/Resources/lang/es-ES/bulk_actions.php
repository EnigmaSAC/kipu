<?php

return [

    'message' => [
        'sent'      => '¿Está seguro que desea marcar el presupuesto seleccionado como <b>enviado</b>? ¿Está seguro que desea marcar los presupuestos seleccionados como <b>enviados</b>?',
        'cancelled' => '¿Está seguro que desea <b>cancelar</b> la factura/recibo seleccionado?|¿Está seguro que desea <b>cancelar</b> las facturas/recibos seleccionados?',
        'delete'    => '¿Está seguro que desea <b>cancelar</b> la factura/recibo seleccionado?|¿Está seguro que desea <b>cancelar</b> las facturas/recibos seleccionados?',
    ],

];
