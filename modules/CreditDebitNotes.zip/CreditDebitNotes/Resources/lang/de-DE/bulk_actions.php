<?php

return [

    'message' => [
        'sent'      => 'Sind Sie sicher das Sie das ausgewählte :type? als <b>versendet</b> markieren möchten?|Sind Sie sicher das Sie die ausgewählten :type? als <b>versendet</b> markieren möchten?',
        'cancelled' => 'Sind Sie sicher das Sie die ausgewählte :type? <b>stornieren</b> möchten?|Sind Sie sicher das Sie die ausgewählten :type? <b>stornieren</b> möchten?',
        'delete'    => 'Sind Sie sicher das Sie die ausgewählte :type? <b>löschen</b> möchten?|Sind Sie sicher das Sie die ausgewählten :type? <b>löschen</b> möchten?',
    ],

];
