<?php

return [

    'message' => [
        'sent'      => 'Er du sikker på, at du vil markere valgte :type som <b>sendt</b>?|Er du sikker på, at du vil markere valgte :type som <b>sendt</b>?',
        'cancelled' => 'Er du sikker på, at du vil <b>annullere</b> valgte :type?|Er du sikker på, at du vil <b>annullere</b> valgte :type?',
        'delete'    => 'Er du sikker på, at du vil <b>slette</b> valgte :type?|Er du sikker på, at du vil <b>slette</b> valgte :type?',
    ],

];
