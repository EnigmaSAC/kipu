<?php

return [

    'message' => [
        'sent'      => 'Are you sure you want to mark selected :type as <b>sent</b>?|Are you sure you want to mark selected :type as <b>sent</b>?',
        'cancelled' => 'Are you sure you want to <b>cancel</b> selected :type?|Are you sure you want to <b>cancel</b> selected :type?',
        'delete'    => 'Are you sure you want to <b>delete</b> selected :type?|Are you sure you want to <b>delete</b> selected :type?',
    ],

];
