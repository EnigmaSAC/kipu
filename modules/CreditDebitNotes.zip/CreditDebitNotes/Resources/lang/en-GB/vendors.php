<?php

return [

    'no_records' => [
        'debit_notes' => 'There is no debit note for this vendor yet. Create a new one now.',
    ],

];
