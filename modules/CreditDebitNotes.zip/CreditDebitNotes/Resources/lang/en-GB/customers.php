<?php

return [

    'no_records' => [
        'credit_notes' => 'There is no credit note for this customer yet. Create a new one now.',
    ],

];
