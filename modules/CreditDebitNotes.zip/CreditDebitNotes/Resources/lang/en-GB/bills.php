<?php

return [

    'bill_amount_is_exceeded' => 'Bill Amount Is Exceeded!',
];
