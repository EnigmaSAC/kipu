<?php

return [

    'message' => [
        'sent'      => 'Êtes-vous sûr de vouloir marquer le devis sélectionné comme <b>envoyé</b>? Êtes-vous sûr de vouloir marquer les devis sélectionnés comme <b>envoyés</b>?',
        'cancelled' => 'Êtes-vous sûr de vouloir <b>annuler</b> la facture sélectionnée ? | Êtes-vous sûr de vouloir <b>annuler</b> les factures sélectionnées ?',
        'delete'    => 'Êtes-vous sûr de vouloir <b>annuler</b> la facture sélectionnée ? | Êtes-vous sûr de vouloir <b>annuler</b> les factures sélectionnées ?',
    ],

];
