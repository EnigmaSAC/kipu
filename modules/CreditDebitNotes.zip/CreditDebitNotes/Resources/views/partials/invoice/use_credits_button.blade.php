<x-button id="button-use-credits">
    {{ trans('credit-debit-notes::invoices.use_credits') }}
</x-button>
