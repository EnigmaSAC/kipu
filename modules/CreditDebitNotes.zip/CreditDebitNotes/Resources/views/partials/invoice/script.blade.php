<script src="{{ asset('modules/CreditDebitNotes/Resources/assets/js/invoices/show.min.js?v=' . module_version('credit-debit-notes')) }}"></script>
