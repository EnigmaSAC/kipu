{{-- @php
 $motivos = [
    1 => 'Anulación de la operación',
    //2 =>'Anulación por error en el RUC',
    //3 => 'Corrección por error en la descripción',
    4 => 'Descuento global',
    5 => 'Descuento por ítem',
    //6 => 'Devolución total',
    7 => 'Devolución por ítem',
    //8 => 'Bonificación',
    9 => 'Disminución en el valor'
 ]   
@endphp


<x-form.group.select
    name="motivo_id"
    id="motivo_id"
    label="Motivo"
    icon="file-invoice-dollar"
    :options="$motivos"
    not-required
    form-group-class="sm:col-span-2"
/> --}}


<x-form.group.select
    name="invoice_id"
    label="{{ trans_choice('general.invoices', 1) }}"
    icon="file-invoice-dollar"
    :options="$invoices"
    :selected="$invoice_id"
    dynamicOptions="invoices"
    not-required
    form-group-class="sm:col-span-2"
/>
