<x-tabs.nav
    id="credit-notes"
    name="{{ trans_choice('credit-debit-notes::general.credit_notes', 2) }}"
/>
