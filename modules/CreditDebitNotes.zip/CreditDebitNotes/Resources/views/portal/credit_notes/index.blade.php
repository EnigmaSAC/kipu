<x-layouts.portal>
    <x-slot name="title">
        {{ trans_choice('credit-debit-notes::general.credit_notes', 2) }}
    </x-slot>

    <x-slot name="content">
        <x-index.container>
            <x-index.search search-string="Modules\CreditDebitNotes\Models\Portal\CreditNote" />

            <x-table>
                <x-table.thead>
                    <x-table.tr>
                        <x-table.th override="class" class="p-0"></x-table.th>
                        @stack('issued_at_th_start')

                        <x-table.th class="w-4/12" hidden-mobile>
                            @stack('issued_at_th_inside_start')

                            <x-sortablelink column="issued_at" title="{{ trans('credit-debit-notes::credit_notes.credit_note_date') }}" />

                            @stack('issued_at_th_inside_end')
                        </x-table.th>

                        @stack('issued_at_th_end')

                        @stack('status_th_start')

                        <x-table.th class="w-3/12" hidden-mobile>
                            @stack('status_th_inside_start')

                            <x-sortablelink column="status" title="{{ trans_choice('general.statuses', 1) }}" />

                            @stack('status_th_inside_end')
                        </x-table.th>

                        @stack('status_th_end')

                        @stack('document_number_th_start')

                        <x-table.th class="w-3/12 sm:table-cell">
                            @stack('document_number_th_inside_start')

                            <x-sortablelink column="document_number" title="{{ trans_choice('general.numbers', 1) }}" />

                            @stack('document_number_th_inside_end')
                        </x-table.th>

                        @stack('document_number_th_end')

                        @stack('amount_th_start')

                        <x-table.th class="w-6/12 sm:w-2/12" kind="amount">
                            @stack('amount_th_inside_start')

                            <x-sortablelink column="amount" title="{{ trans('general.amount') }}" />

                            @stack('amount_th_inside_end')
                        </x-table.th>

                        @stack('amount_th_end')
                    </x-table.tr>
                </x-table.thead>

                <x-table.tbody>
                    @foreach($credit_notes as $item)
                        @php $paid = $item->paid; @endphp
                        <x-table.tr href="{{ route('portal.credit-debit-notes.credit-notes.show', $item->id) }}">
                            <x-table.td kind="action"></x-table.td>
                            @stack('issued_at_td_start')

                            <x-table.td class="w-4/12" hidden-mobile>
                                @stack('issued_at_td_inside_start')

                                <x-slot name="second">
                                    <x-date date="{{ $item->issued_at }}" />
                                </x-slot>

                                @stack('issued_at_td_inside_end')
                            </x-table.td>

                            @stack('issued_at_td_end')

                            @stack('status_td_start')

                            <x-table.td class="w-3/12" hidden-mobile>
                                @stack('status_td_inside_start')

                                <x-index.status status="{{ $item->status }}" background-color="bg-{{ $item->status_label }}" text-color="text-text-{{ $item->status_label }}" />

                                @stack('status_td_inside_end')
                            </x-table.td>

                            @stack('status_td_end')

                            @stack('document_number_td_start')

                            <x-table.td class="w-3/12  sm:table-cell">
                                @stack('document_number_td_inside_start')

                                <x-slot name="first" class="w-20 font-normal group" data-tooltip-target="tooltip-information-{{ $item->id }}" data-tooltip-placement="left" override="class">
                                    <span class="border-black border-b border-dashed">
                                        {{ $item->document_number }}
                                    </span>

                                    <div class="w-28 absolute h-10 -ml-12 -mt-6"></div>

                                    <x-documents.index.information :document="$item" show-route="portal.credit-debit-notes.credit-notes.show"/>
                                </x-slot>

                                @stack('document_number_td_inside_end')
                            </x-table.td>

                            @stack('document_number_td_end')

                            @stack('amount_td_start')

                            <x-table.td class="w-6/12 sm:w-2/12" kind="amount">
                                @stack('amount_td_inside_start')

                                <x-money :amount="$item->amount" :currency="$item->currency_code" />

                                @stack('amount_td_inside_end')
                            </x-table.td>

                            @stack('amount_td_end')
                        </x-table.tr>
                    @endforeach
                </x-table.tbody>
            </x-table>

            <x-pagination :items="$credit_notes" />
        </x-index.container>
    </x-slot>

    <x-script folder="portal" file="apps" />
</x-layouts.portal>
