<?php

namespace Modules\CreditDebitNotes\Jobs\Refund;

use App\Abstracts\Job;
use App\Interfaces\Job\ShouldCreate;
use App\Jobs\Banking\CreateTransaction;
use App\Jobs\Document\CreateDocumentHistory;
use App\Models\Banking\Transaction;
use App\Models\Document\Document;
use App\Traits\Currencies;
use Date;
use Modules\CreditDebitNotes\Models\CreditNote;
use Throwable;

class CreateRefundTransaction extends Job implements ShouldCreate
{
    use Currencies;

    protected Document $document;

    /**
     * Create a new job instance.
     */
    public function __construct($document, $request = [])
    {
        $this->document = $document;

        parent::__construct($request);
    }

    /**
     * Execute the job.
     *
     * @throws Throwable
     */
    public function handle(): Transaction
    {
        $this->prepareRequest();

        \DB::transaction(function () {
            $this->model = $this->dispatch(new CreateTransaction($this->request));

            $this->createHistory();
        });

        return $this->model;
    }

    protected function prepareRequest(): void
    {
        $this->request['company_id'] = company_id();
        $this->request['type'] = ($this->document instanceof CreditNote) ? 'credit_note_refund' : 'debit_note_refund';
        $this->request['paid_at'] = isset($this->request['paid_at']) ? $this->request['paid_at'] : Date::now()->format('Y-m-d');
        $this->request['amount'] = isset($this->request['amount']) ? $this->request['amount'] : $this->document->amount;
        $this->request['currency_code'] = isset($this->request['currency_code']) ? $this->request['currency_code'] : $this->document->currency_code;
        $this->request['currency_rate'] = config('money.currencies.' . $this->request['currency_code'] . '.rate');
        $this->request['account_id'] = isset($this->request['account_id']) ? $this->request['account_id'] : setting('default.account');
        $this->request['document_id'] = isset($this->request['document_id']) ? $this->request['document_id'] : $this->document->id;
        $this->request['category_id'] = isset($this->request['category_id']) ? $this->request['category_id'] : $this->document->category_id;
        $this->request['contact_id'] = isset($this->request['contact_id']) ? $this->request['contact_id'] : $this->document->contact_id;
        $this->request['payment_method'] = isset($this->request['payment_method']) ? $this->request['payment_method'] : setting('default.payment_method');
        $this->request['notify'] = isset($this->request['notify']) ? $this->request['notify'] : 0;
    }

    protected function createHistory(): void
    {
        $amount = money((double) $this->model->amount, (string) $this->model->currency_code, true)->format();

        if ($this->document instanceof CreditNote) {
            $history_desc =  trans('credit-debit-notes::credit_notes.refunded_customer_with', ['customer' => $this->document->contact_name, 'amount' => $amount]);
        } else {
            $history_desc =  trans('credit-debit-notes::debit_notes.received_refund_from_vendor', ['vendor' => $this->document->contact_name, 'amount' => $amount]);
        }
        $this->dispatch(new CreateDocumentHistory($this->document, 0, $history_desc));
    }
}
