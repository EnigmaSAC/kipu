<?php

namespace Modules\CreditDebitNotes\Observers;

use App\Abstracts\Observer;
use App\Models\Common\Contact;
use App\Models\Document\Document;
use Modules\CreditDebitNotes\Models\CreditNoteDetails as Model;
use App\Models\Document\DocumentItem;
use App\Models\Setting\Tax;
use Carbon\Carbon;
use DateTime;
use Exception;
use Illuminate\Support\Facades\Storage;
use Greenter\Model\Client\Client;
use Greenter\Model\Company\Company;
use Greenter\Model\Company\Address;
use Greenter\Model\Sale\FormaPagos\FormaPagoContado;
use Greenter\Model\Sale\FormaPagos\FormaPagoCredito;
use Greenter\Model\Sale\Invoice;
use Greenter\Model\Sale\Note;
use Greenter\Model\Sale\SaleDetail;
use Greenter\Model\Sale\Legend;
use Greenter\Ws\Services\SunatEndpoints;
use App\Events\Document\DocumentMarkedSent;
use Greenter\See;
use Modules\CustomFields\Models\FieldTypeOption;
use Modules\CustomFields\Models\FieldValue;
use Modules\Sunat\Http\Controllers\SunatTransactionController;
use Modules\Sunat\Models\Sunat;
use Modules\Sunat\Models\SunatTransaction;
use Modules\Sunat\Observers\Document\Util;


// use App\Models\Banking\Transaction as Model;

class CreditNoteSunat extends Observer
{

    public $afterCommit = true;
    
    public function created(Model $credit_note_detail): String
    {
        $util = Util::getInstance();
        $credit_note = Document::where('id', $credit_note_detail->document_id)->first();
        $invoice = Document::where('id', $credit_note_detail->invoice_id)->first();
        

        $documente_items = $credit_note->items;
        $sunat_data = Sunat::where('company_id', $credit_note->company_id)->first();
        $explode = (explode('-', $credit_note->document_number));
        
        $note = new Note();
        $contact = $credit_note->contact;
        $field_value = FieldValue::where('model_id', $contact->id)->where('model_type', Contact::class)->first();
        $field_option = FieldTypeOption::find(intval($field_value->value));
        $tipo_doct = $field_option->value == "Factura" ? '01' : '03';
        $tipo_doct_client = $field_option->value == "Factura" ? '6' : '1';
        $cod_motivo = ($credit_note->amount === $invoice->amount) ? '06' : '07';
        $des_motivo = ($credit_note->amount === $invoice->amount) ? 'Devolución Total' : 'Devolución Por Item';

        $mtoOperGravadas = $documente_items->reduce(function (?int $carry, $item) {
            return $carry + $item->tax;
        }, 0);
        $client = (new Client())
        ->setTipoDoc($tipo_doct_client)
        ->setNumDoc($contact->tax_number)
        ->setRznSocial($contact->name);

        $address = (new Address())
                    ->setUbigueo($sunat_data->ubigueo)
                    ->setDepartamento($sunat_data->province)
                    ->setProvincia($sunat_data->province)
                    ->setDistrito($sunat_data->district)
                    ->setUrbanizacion($sunat_data->housing)
                    ->setDireccion($credit_note->contact_address)
                    ->setCodLocal($sunat_data->code_location); // Codigo de establecimiento asignado por SUNAT, 0000 por defecto.

        $company = (new Company())
        ->setRuc($sunat_data->ruc)
        ->setRazonSocial($credit_note->company->name)
        ->setNombreComercial($credit_note->company->name)
        ->setAddress($address);

        $note->setUblVersion('2.1')
            ->setTipoDoc('07')
            ->setSerie($explode[0])
            ->setCorrelativo($explode[1])
            ->setFechaEmision(new DateTime())
            ->setTipDocAfectado($tipo_doct) // Tipo Doc: Factura
            ->setNumDocfectado($invoice->document_number) // Factura: Serie-Correlativo
            ->setCodMotivo($cod_motivo) // Catalogo. 09
            ->setDesMotivo($des_motivo)
            ->setTipoMoneda($credit_note->currency_code)
            //->setGuias([/* Guias (Opcional) */(new Document())->setTipoDoc('09')->setNroDoc('0001-213')])
            ->setCompany($company)
            ->setClient($client)
            ->setMtoOperGravadas($credit_note->amount - $mtoOperGravadas) 
            ->setMtoIGV($mtoOperGravadas)
            ->setTotalImpuestos($mtoOperGravadas)
            ->setMtoImpVenta($credit_note->amount);

        $items = [];
        foreach($documente_items as $item){
            $tax_percentage = 0;
                foreach ($item->tax_ids as $tax_id) {
                    $tax = Tax::where('id', $tax_id)->first();
                    $tax_percentage += (float) round($tax->rate, 2);
                }
                $mtoPrecioUnitario =  $item->price + ($item->price* $tax_percentage/100); 
            $newItem = (new SaleDetail())
                    ->setCodProducto($item->sku)
                    ->setUnidad('NIU') // Unidad - Catalog. 03
                    ->setCantidad((float)round($item->quantity))
                    ->setMtoValorUnitario((float)round($item->price))
                    ->setDescripcion($item->name)
                    ->setMtoBaseIgv((float)round($item->total))
                    ->setPorcentajeIgv($tax_percentage) // 18%
                    ->setIgv((float)round($item->tax))
                    ->setTipAfeIgv('10') // Gravado Op. Onerosa - Catalog. 07
                    ->setTotalImpuestos((float)round($item->tax)) // Suma de impuestos en el detalle
                    ->setMtoValorVenta((float)round($item->total))
                    ->setMtoPrecioUnitario((float)round($mtoPrecioUnitario));
            $items[] = $newItem;
        }
        
        $legend = (new Legend())
        ->setCode('1000') // Monto en letras - Catalog. 52
        ->setValue('SON DOSCIENTOS TREINTA Y SEIS CON 00/100 SOLES');

        $note->setDetails($items)->setLegends([$legend]);

        $see = $util->getSee($sunat_data->is_production === 0 ? SunatEndpoints::FE_BETA : SunatEndpoints::FE_PRODUCCION, $sunat_data);

        //event(new DocumentMarkedSent($credit_note));
        //$invoice->status = 'anulado';
        //$invoice->save();
        $result = $see->send($note);
        if (!$result->isSuccess()) {
            throw new Exception($result->getError()->getMessage());
        }

        $cdr = $result->getCdrResponse();
        $code = (int)$cdr->getCode();
        $statu = '';
        switch (true) {
            case $code === 0:
                if (count($cdr->getNotes()) > 0) {
                    $statu = 'Aceptada con advertencias';
                } else {
                    $statu = 'Aceptada';
                }
                break;
        
            case $code >= 2000 && $code <= 3999:
                $statu = 'Rechazada';
                break;
        
            default:
                $statu = 'Excepción';
                break;
        }
    
        $transaction_data = [
            'sunat_id' => $sunat_data->id,
            'company_id' => $credit_note->company_id,
            'document_id' => $credit_note->id,
            'document_number' => $credit_note->document_number,
            'razon_social' => $contact->name,
            'ruc_dni' => $sunat_data->ruc,
            'statu' => $statu,
        ];

        SunatTransactionController::store($transaction_data);
        Storage::disk('local')->put("$sunat_data->ruc/$credit_note->document_number.zip", $result->getCdrZip());
        Storage::disk('local')->put("$sunat_data->ruc/$credit_note->document_number.xml", $see->getFactory()->getLastXml());

        return $cdr->getDescription();
        
    }

/*
        // Cliente
        
        // Emisor
        

        
        
        $mtoOperGravadas = $documente_items->reduce(function (?int $carry, $item) {
            return $carry + $item->tax;
        }, 0);
        $today = Carbon::today(); 
        $due_at = Carbon::parse($document->due_at); 
        
        $formaPago = ($due_at->gt($today) )  ? new FormaPagoCredito((float) round($document->amount, 2))  : new FormaPagoContado();

        //$doc_type = str_starts_with($explode[0], 'F') ? '01' : '03';
        // Venta    
        $invoice = (new Invoice())
        ->setUblVersion('2.1')
        ->setTipoOperacion('0101') // Venta - Catalog. 51
        ->setTipoDoc($tipo_doct) // Factura - Catalog. 01 
        ->setSerie($explode[0])
        ->setCorrelativo($explode[1])
        ->setFechaEmision(new \DateTime(date('Y-m-d H:i:s', strtotime($document->created_at)))) // Zona horaria: Lima
        ->setFormaPago(new FormaPagoContado()) // FormaPago: Contado
        ->setTipoMoneda($document->currency_code) // Sol - Catalog. 0)2
        ->setCompany($company)
        ->setClient($client)
        ->setMtoOperGravadas($document->amount - $mtoOperGravadas) 
        ->setMtoIGV($mtoOperGravadas)
        ->setTotalImpuestos($mtoOperGravadas)
        ->setValorVenta($document->amount - $mtoOperGravadas)
        ->setSubTotal($document->amount)
        ->setMtoImpVenta($document->amount)
        ;
*/
}