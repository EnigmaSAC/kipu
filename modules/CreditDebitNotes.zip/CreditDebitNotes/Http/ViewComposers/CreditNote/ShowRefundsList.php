<?php

namespace Modules\CreditDebitNotes\Http\ViewComposers\CreditNote;

use App\Models\Banking\Transaction;
use Illuminate\View\View;
use Modules\CreditDebitNotes\Models\CreditNote;
use Modules\CreditDebitNotes\Models\DebitNote;

class ShowRefundsList
{
    public function compose(View $view): void
    {
        $view_data = $view->getData();

        if (!in_array($view_data['type'], [CreditNote::TYPE, DebitNote::TYPE])) {
            return;
        }

        $document = $view_data['document'];

        if ($document->credit_customer_account) {
            return;
        }

        if ($document->status !== 'sent') {
            return;
        }

        $refunds = Transaction::documentId($document->id)->get();

        // TODO: adjust for a case with different currencies in transactions
        $amount_available = $document->amount - $refunds->sum('amount');

        $view_data['description'] = trans('credit-debit-notes::general.amount_available').': '.
            '<span class="font-medium">'.money($amount_available, $document->currency_code, true).'</span>';
        $view_data['amount_available'] = $amount_available;

        if ($document->type === CreditNote::TYPE) {
            $view_data['accordion_title'] = trans('credit-debit-notes::credit_notes.refund_customer');
            $view_data['button_text'] = trans('credit-debit-notes::credit_notes.make_refund');
            $view_data['list_title'] = trans('credit-debit-notes::credit_notes.refunds_made');
            $view_data['refund_translation'] = 'credit-debit-notes::credit_notes.refund_transaction';
        } else {
            $view_data['accordion_title'] = trans('credit-debit-notes::debit_notes.receive_refund');
            $view_data['button_text'] = trans('credit-debit-notes::debit_notes.receive_refund');
            $view_data['list_title'] = trans('credit-debit-notes::debit_notes.refunds_received');
            $view_data['refund_translation'] = 'credit-debit-notes::debit_notes.refund_transaction';
        }

        $view->getFactory()->startPush(
            'get_paid_start',
            view('credit-debit-notes::partials.document.refunds_list', $view_data)
        );
    }
}
