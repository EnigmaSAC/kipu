<script type="text/javascript">
    var {!! $field->code !!} = {!! $values ? json_encode($values) : '[]' !!};
</script>
